# Engenharia Segura — versão 2.2.6

Alteração única desta versão:
- O botão **Solicitar consultoria** abre diretamente o WhatsApp de contato.
- Mensagem automática: "Olá, Artur. Conheci a Engenharia Segura pelo site e gostaria de solicitar uma consultoria."
- Nenhuma alteração de layout, CSS, fundo, foto, cores ou demais botões.

Contato configurado: (94) 98809-0727
