# Engenharia Segura — versão 2.2.4

Versão conservadora baseada no layout original da 2.2.

Mudanças:
- "Sobre" passa a aparecer como "Sobre mim";
- a chamada "Conheça mais sobre mim" aponta para a seção `#sobre`;
- links do nome Artur Cavalcante que apontassem para Artigos passam a apontar para `#sobre`;
- a seção Artigos permanece separada;
- nenhum layout/CSS foi alterado.
