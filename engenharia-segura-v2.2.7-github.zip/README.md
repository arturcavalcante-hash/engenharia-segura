# Engenharia Segura — versão 2.2.7

Atualização visual leve, mantendo o layout principal.

O que mudou:
- animação suave quando seções entram na tela;
- efeitos discretos ao passar o mouse em botões e cards;
- nova seção “Últimos vídeos” com três conteúdos recentes;
- nenhum ajuste no Hero, fundo da mina, foto, cores-base ou estrutura principal.

Objetivo:
dar mais vida ao site sem descaracterizar o visual atual.
