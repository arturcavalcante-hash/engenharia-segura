# Engenharia Segura — versão 2.2.10

Correção pontual da faixa dinâmica.

Mudanças:
- faixa agora é escura e compacta;
- textos e ícones ficaram visíveis;
- pontos separadores em laranja;
- rolagem contínua mais suave;
- Hero, fundo da mina, foto, botões e layout principal não foram alterados.
