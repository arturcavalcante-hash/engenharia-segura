# Engenharia Segura — versão 2.2.5

Versão corrigida para:
- restaurar o fundo da mina com a foto;
- manter o layout anterior;
- ajustar apenas a navegação "Sobre mim".

## Arquivos principais
- index.html
- style.css
- assets/engenharia-segura-v2-2.png

## Observação
Também foi incluída uma cópia da imagem `engenharia-segura-v2-2.png` na raiz do projeto
como segurança extra para uploads manuais.
